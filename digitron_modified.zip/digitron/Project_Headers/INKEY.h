/*
 * INKEY.h
 *
 *  Created on: Dec 18, 2015
 *      Author: dell
 */

#ifndef INKEY_H_
#define INKEY_H_


void delayms(unsigned int number);
void enable_irq(int irq);
void EN_Init();
void KEY_Init();

#endif /* INKEY_H_ */
